Create a directory on your PC
Copy Archive.zip into the directory
Unzip the file
Launch index.html

For suggestions or inquiries, rcassata@cisco.com
